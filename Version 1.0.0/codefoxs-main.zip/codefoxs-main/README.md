# codefoxs
This software is for graphic work and can be used to graphically design a website Whatever your heart desires, design it and get the code for whatever you want With this software, you can create websites or mobile and desktop applications, or even design logos, or even cartoon characters, or anything else that comes to mind.

Earlier this month, the startup unveiled its first technology in the field of design, and Aria Behrozian spoke about this software in a live unveiling and shared a general view of the software.
According to the manufacturer, this software is made to help design. Work with this software in such a way that in the software development environment, you can design anything and get its code, or more precisely, you do not need programming to build anything else.
According to the project engineers, this software has been freely available to all people since the beginning of this monthAnd you can run the project from the project gate hub repository in the web environment


### فارسی
در اوایل این ماه ، استارتآپ کویت سورس از اولین فناوری خود در زمینه طراحی رونمایی کرد و آریا بهروزیان در یک رونمایی زنده در مورد این نرم افزار صحبت کرد و دیدگاه کلی این نرم افزار را به اشتراک گذاشت.
طبق گفته سازنده ، این نرم افزار برای کمک به طراحی ساخته شده است. با این نرم افزار به گونه ای کار کنید که در محیط توسعه نرم افزار بتوانید هر چیزی را طراحی کرده و کد آن را دریافت کنید یا به عبارت دقیق تر ، برای ساختن چیز دیگری نیازی به برنامه نویسی ندارید.
به گفته مهندسان پروژه ، این نرم افزار از ابتدای ماه جاری به صورت رایگان در دسترس همه افراد قرار گرفته است و شما می توانید پروژه را از مخزن هاب پروژه در محیط وب اجرا
کنید

### عربی
في وقت سابق من هذا الشهر ، كشفت الشركة الناشئة عن أول تقنية لها في مجال التصميم ، وتحدثت أريا بهروزيان عن هذا البرنامج في عرض مباشر وشاركت نظرة عامة عن البرنامج. وفقًا للشركة المصنعة ، تم تصميم هذا البرنامج للمساعدة في التصميم. اعمل مع هذا البرنامج بطريقة تتيح لك في بيئة تطوير البرامج تصميم أي شيء والحصول على الكود الخاص به ، أو بشكل أكثر دقة ، لا تحتاج إلى البرمجة لإنشاء أي شيء آخر. وفقًا لمهندسي المشروع ، كان هذا البرنامج متاحًا مجانًا لجميع الأشخاص منذ بداية هذا الشهر ويمكنك تشغيل المشروع من مستودع بوابة المشروع في بيئة الويب



## Aryia Behroziuan Creator
Artificial intelligence and data mining programmer and specialist working on genetics and in-depth learning projects and natural language processing and computer vision And 
born in 2007 in Iran And work as an engineer and manager of a QitSource startup development team

### فارسی
برنامه نویس و متخصص هوش مصنوعی و داده کاوی و کار در زمینه ژنتیک و پروژه های یادگیری عمیق و پردازش زبان طبیعی و دید کامپیوتر و
متولد 2007 در ایران و به عنوان مهندس و مدیر تیم توسعه استارت آپ کویت سورس کار می کند


## Qitsource | Startup
This startup operates in the field of bioinformatics, artificial intelligence and biotechnology and is an innovation agency for the growth and development of biotechnology technologies. The development team manager of this startup is Aryia Behroziuan

### فارسی
این استارت آپ در زمینه بیوانفورماتیک ، هوش مصنوعی و بیوتکنولوژی فعالیت می کند و یک آژانس نوآوری برای رشد و توسعه فناوری های بیوتکنولوژی است. مدیر تیم توسعه این استارت آپ اریا بهروزیان است

## عربی
تعمل هذه الشركة الناشئة في مجال المعلوماتية الحيوية والذكاء الاصطناعي والتكنولوجيا الحيوية وهي وكالة ابتكار لنمو تقنيات التكنولوجيا الحيوية وتطويرها. مدير فريق التطوير لهذه الشركة الناشئة هو اریا بهروزیان




